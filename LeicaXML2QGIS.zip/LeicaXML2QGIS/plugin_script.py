# Nome file: LeicaXML2QGIS.py
# Copyright (C) 2025 Alessandro Pavan, Michele Potleca
#
# Questo programma è software libero: puoi ridistribuirlo e/o
# modificarlo secondo i termini della GNU General Public License
# come pubblicata dalla Free Software Foundation, versione 3.
#
# Questo programma è distribuito nella speranza che sia utile,
# ma SENZA ALCUNA GARANZIA; senza neppure la garanzia implicita
# di COMMERCIABILITÀ o di IDONEITÀ PER UN PARTICOLARE SCOPO.
# Vedi la GNU General Public License per ulteriori dettagli.
#
# Dovresti aver ricevuto una copia della GNU General Public License
# insieme a questo programma. In caso contrario, vedi <https://www.gnu.org/licenses/>.



from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsFields,
    QgsField
)
from qgis.PyQt.QtCore import QVariant
import xml.etree.ElementTree as ET

def extract_and_display_points(xml_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()

    points = []
    for geodetic in root.iter():
        if geodetic.tag.endswith("Geodetic"):
            lat = geodetic.attrib.get("lat")
            lon = geodetic.attrib.get("lon")
            quality = next((c for c in geodetic if c.tag.endswith("CoordinateQuality")), None)
            if lat and lon and quality is not None:
                qxx = quality.attrib.get("Qxx")
                qxy = quality.attrib.get("Qxy")
                qxz = quality.attrib.get("Qxz")
                points.append((float(lat), float(lon), qxx, qxy, qxz))

    # Crea layer vettoriale temporaneo
    vl = QgsVectorLayer("Point?crs=EPSG:4326", "LandXML Geodetic Points", "memory")
    pr = vl.dataProvider()

    # Aggiungi campi attributi
    pr.addAttributes([
        QgsField("Qxx", QVariant.String),
        QgsField("Qxy", QVariant.String),
        QgsField("Qxz", QVariant.String)
    ])
    vl.updateFields()

    # Crea le features
    features = []
    for lat, lon, qxx, qxy, qxz in points:
        feat = QgsFeature()
        feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        feat.setAttributes([qxx, qxy, qxz])
        features.append(feat)

    pr.addFeatures(features)
    vl.updateExtents()

    # Aggiungi il layer a QGIS
    QgsProject.instance().addMapLayer(vl)
