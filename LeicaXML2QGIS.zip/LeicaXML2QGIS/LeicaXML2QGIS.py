# Nome file: LeicaXML2QGIS.py
# Copyright (C) 2025 Alessandro Pavan, Michele Potleca
#
# Questo programma è software libero: puoi ridistribuirlo e/o
# modificarlo secondo i termini della GNU General Public License
# come pubblicata dalla Free Software Foundation, versione 3.
#
# Questo programma è distribuito nella speranza che sia utile,
# ma SENZA ALCUNA GARANZIA; senza neppure la garanzia implicita
# di COMMERCIABILITÀ o di IDONEITÀ PER UN PARTICOLARE SCOPO.
# Vedi la GNU General Public License per ulteriori dettagli.
#
# Dovresti aver ricevuto una copia della GNU General Public License
# insieme a questo programma. In caso contrario, vedi <https://www.gnu.org/licenses/>.


from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox
import os

from .plugin_script import extract_and_display_points

class LeicaXML2QGIS:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        self.action = QAction("LandXML ➜ KML", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("LandXML to KML", self.action)

    def unload(self):
        self.iface.removePluginMenu("LandXML to KML", self.action)

    def run(self):
        xml_path, _ = QFileDialog.getOpenFileName(None, "Seleziona file LandXML", "", "LandXML (*.xml)")
        if not xml_path:
            return

        output_path = os.path.join(os.path.dirname(xml_path), "output.kml")
        try:
            extract_and_display_points(xml_path)
            QMessageBox.information(None, "Fatto", f"KML generato:\n{output_path}")
        except Exception as e:
            QMessageBox.critical(None, "Errore", str(e))
