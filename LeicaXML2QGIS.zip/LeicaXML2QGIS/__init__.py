def classFactory(iface):
    from .LeicaXML2QGIS import LeicaXML2QGIS
    return LeicaXML2QGIS(iface)
